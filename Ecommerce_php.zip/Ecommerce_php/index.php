<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        .form {
            max-width: 50%;
            margin-left: 25%;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="row text-center mt-5">
        <h1>Please Sign In To Continue</h1>
    </div>
    <div class="container mt-5">
        <form action="login.php" method="POST" class="form">
            <div class="mb-3">
                <label for="email" class="form-label">Enter Your Email</label>
                <input type="text" class="form-control" id="email" name="email" placeholder="xyz@email.com">
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">Enter password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="******">
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Login</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
            <div class="mt-5 text-center">
                <a href="register.php">Click here if your new</a>
            </div>
        </form>
    </div>
</body>

</html>