-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2024 at 12:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `userId` int(30) NOT NULL,
  `productId` int(30) NOT NULL,
  `size` varchar(4) NOT NULL,
  `qty` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `userId`, `productId`, `size`, `qty`) VALUES
(147, 10, 10, 'M', 2),
(149, 13, 8, 'L', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(20) NOT NULL,
  `categorydescription` varchar(25) NOT NULL,
  `categoryImage` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categorydescription`, `categoryImage`) VALUES
(3, 'jackets', 'this is for jackets', 'black-jacket.png');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `userId` int(30) NOT NULL,
  `productId` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `userId`, `productId`) VALUES
(22, 3, 3),
(23, 3, 3),
(20, 3, 5),
(24, 3, 7),
(19, 3, 9),
(25, 3, 9),
(93, 13, 8);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `categoryId` int(4) DEFAULT NULL,
  `productName` varchar(25) NOT NULL,
  `producDescription` varchar(25) NOT NULL,
  `productImage` varchar(35) NOT NULL,
  `productPrice` double DEFAULT NULL,
  `usersFavoriteId` int(4) DEFAULT NULL,
  `discount` int(3) DEFAULT NULL,
  `size` varchar(30) NOT NULL,
  `qty` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `categoryId`, `productName`, `producDescription`, `productImage`, `productPrice`, `usersFavoriteId`, `discount`, `size`, `qty`) VALUES
(3, NULL, 'Black Jacket', 'Awsome Jacket', 'black-jacket.png', 10, NULL, 20, 'M,L,XL', 20),
(4, NULL, 'blue Jacket', 'nice Jacket', 'blue-jacket.png', 10, NULL, 20, 'M,L,XL', 20),
(5, NULL, 'jeans', 'awsome pents', 'jeans.png', 10, NULL, 10, 'M,L,XL', 20),
(6, NULL, 'Black TShirt', 'Soft Teachert', 'black-tshirt.png', 10, NULL, NULL, 'M,L,XL', 20),
(7, NULL, 'Blue TShirt', 'Soft Teachert', 'blue-tshirt.png', 10, NULL, 10, 'M,L,XL', 20),
(8, NULL, 'White TShirt', 'Soft Teachert', 'white-tshirt.png', 10, NULL, 15, 'M,L,XL', 20),
(9, NULL, 'White Dress', 'very nice dress', 'white-dress.png', 10, NULL, NULL, 'M,L,XL', 20),
(10, NULL, 'Black Dress', 'very nice dress', 'black-dress.png', 10, NULL, NULL, 'M,L,XL', 20),
(11, NULL, 'Blue Dress', 'very nice dress', 'blue-dress.png', 10, NULL, NULL, 'M,L,XL', 20),
(12, NULL, 'Black shoes', 'very nice shoes', 'black-shoes.png', 10, NULL, NULL, 'M,L,XL', 20),
(13, NULL, 'White shoes', 'very nice shoes', 'white-shoes.png', 10, NULL, NULL, 'M,L,XL', 20),
(14, NULL, 'Blue shoes', 'very nice shoes', 'blue-shoes.png', 10, NULL, NULL, 'M,L,XL', 20),
(15, 3, '[value-3]', '[value-4]', '[value-5]', 11, NULL, 10, 'L', 2);

-- --------------------------------------------------------

--
-- Table structure for table `shippingaddress`
--

CREATE TABLE `shippingaddress` (
  `id` int(11) NOT NULL,
  `userId` int(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `street` varchar(30) NOT NULL,
  `building` varchar(30) NOT NULL,
  `cityName` varchar(30) NOT NULL,
  `countryPhoneCode` varchar(30) NOT NULL,
  `phone` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shippingaddress`
--

INSERT INTO `shippingaddress` (`id`, `userId`, `address`, `street`, `building`, `cityName`, `countryPhoneCode`, `phone`) VALUES
(1, 2, 'Bakhoun', 'main road', 'samad', 'danyeh', '+961', 70528794),
(2, 10, 'asfsf', 'sfafsa', 'asfasf', 'afaswf', '+961', 12123),
(3, 11, 'tripoly', 'azmi', 'batata', 'tripoly', '+961', 711827),
(4, 13, 'bakhoun', 'day3a', 'el sabil', 'danyeh', '+961', 3135043);

-- --------------------------------------------------------

--
-- Table structure for table `shippingorder`
--

CREATE TABLE `shippingorder` (
  `id` int(11) NOT NULL,
  `shippingId` int(30) NOT NULL,
  `productId` int(30) NOT NULL,
  `total` int(50) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(30) NOT NULL,
  `size` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shippingorder`
--

INSERT INTO `shippingorder` (`id`, `shippingId`, `productId`, `total`, `date`, `status`, `size`, `qty`) VALUES
(2, 1, 9, 1, '0000-00-00', '01/01/2022', 'fdssf', 'sffs'),
(3, 1, 8, 27, '2024-01-01', 'confirmed', 'S,XL', '1,1'),
(4, 1, 8, 27, '2024-01-01', 'confirmed', 'S,XL', '1,1'),
(5, 1, 8, 27, '2024-01-01', 'confirmed', 'S,XL', '1,1'),
(6, 1, 9, 80, '2024-01-01', 'confirmed', 'M', '4'),
(7, 1, 9, 20, '2024-01-01', 'confirmed', 'M', '1'),
(8, 1, 9, 20, '2024-01-01', 'confirmed', 'L', '1'),
(9, 1, 9, 40, '2024-01-01', 'confirmed', 'XL', '2'),
(10, 1, 9, 40, '2024-01-01', 'confirmed', 'S', '2'),
(11, 1, 9, 40, '2024-01-01', 'confirmed', 'S', '2'),
(12, 1, 9, 80, '2024-01-01', 'confirmed', 'M,M', '2,2'),
(13, 1, 9, 40, '2024-01-01', 'confirmed', 'XL', '2'),
(14, 1, 9, 20, '2024-01-01', 'confirmed', 'S', '1'),
(15, 1, 10, 60, '2024-01-01', 'confirmed', 'M', '3'),
(16, 1, 9, 60, '2024-01-01', 'confirmed', 'XL', '3'),
(17, 1, 0, 0, '2024-01-01', 'confirmed', '', ''),
(18, 1, 10, 40, '2024-01-01', 'confirmed', 'XL,XL', '1,1'),
(19, 1, 8, 22, '2024-01-01', 'confirmed', 'XL,M', '2,2'),
(20, 1, 8, 7, '2024-01-01', 'confirmed', 'L', '1'),
(21, 1, 7, 9, '2024-01-01', 'confirmed', 'XL', '1'),
(22, 2, 9, 60, '2024-01-03', 'confirmed', 'XL', '3'),
(23, 2, 9, 60, '2024-01-04', 'confirmed', 'XL', '3'),
(25, 4, 3, 22, '2024-01-07', 'confirmed', 'M', '2');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullName` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullName`, `email`, `password`, `role`) VALUES
(2, 'khoder osman', 'khoder.osman@email.com', 'khoder123', 'admin'),
(3, 'ola salloum', 'ola.salloum@email.com', 'ola123', 'user'),
(4, 'abdallah hello', 'abdallah.hello@email.com', 'aballah123', 'user'),
(5, 'khoder osman3', 'khoder.osman@email.com', '797d8ab72fb90158eb10f16dac3846', 'user'),
(6, 'khoder osman4', 'khoder.osman4@email.com', '797d8ab72fb90158eb10f16dac3846', 'user'),
(7, 'youssef', 'youssef.trabulsi@email.com', '046ae0efbb9f7b5d5d8f174fed3a0e', 'user'),
(8, 'abed salloum', 'abed.salloum@email.com', '45159656f36ab98de7a49b4c660bd5', 'user'),
(9, 'ola salloum3', 'ola.salloum3@email.com', '$2y$10$Z5X6zbEXvzbG2O8Qzxr99uQ', 'user'),
(10, 'youssef trabuls', 'youssef.trabulsi1@email.com', '$2y$10$h3rIyIiRIcB7Fdol4C/EwO5E8spSaTnkPSiECW060tyMUVhxgyNwi', 'user'),
(11, 'youssef trabuls', 'youssef.trabulsi2@email.com', '$2y$10$T9hjEFf.iuOzAKL0LvZgV.qbcxHPdQvIoNzTqLKOm2lrXNTc/FOfO', 'user'),
(12, 'Tam,a', 'youssef.trabulsi1@email.com', '$2y$10$xxV9k.LDbZj7dzBvY7v9HuaXG.H/ieYCuCPwl8VAFTIWOZdu470l6', 'user'),
(13, 'Tammam Ghoul', 'tammam.ghoul@email.com', '$2y$10$/q7a8uz0truAVupYcSOVkeD8xHuOMKKCVNK6MIyE1p.nbmA/QAO1u', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`,`productId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usersFavoriteId` (`usersFavoriteId`);

--
-- Indexes for table `shippingaddress`
--
ALTER TABLE `shippingaddress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- Indexes for table `shippingorder`
--
ALTER TABLE `shippingorder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shippingId` (`shippingId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `shippingaddress`
--
ALTER TABLE `shippingaddress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shippingorder`
--
ALTER TABLE `shippingorder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`);

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`usersFavoriteId`) REFERENCES `favorites` (`id`) ON UPDATE SET NULL,
  ADD CONSTRAINT `product_ibfk_3` FOREIGN KEY (`categoryId`) REFERENCES `category` (`id`) ON UPDATE SET NULL;

--
-- Constraints for table `shippingaddress`
--
ALTER TABLE `shippingaddress`
  ADD CONSTRAINT `shippingaddress_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`);

--
-- Constraints for table `shippingorder`
--
ALTER TABLE `shippingorder`
  ADD CONSTRAINT `shippingorder_ibfk_2` FOREIGN KEY (`shippingId`) REFERENCES `shippingaddress` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
