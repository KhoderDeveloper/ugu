<?php
include '../connection.php';
if (isset($_POST['categoryName']) && ($_POST['categoryName'] != "")
    && isset($_POST['categorydescription']) && ($_POST['categorydescription'] != "")
) {
    $categoryName = $_POST['categoryName'];
    $categorydescription = $_POST['categorydescription'];
    if (!empty($_FILES['categoryImage']['name'])) {
        $image = $_FILES['categoryImage']['name'];
        move_uploaded_file($_FILES['categoryImage']['tmp_name'], "../assets/category/$image");


        $query = "INSERT INTO category VALUES( null, '$categoryName', '$categorydescription', '$image')";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            die("error in insert command");
        } else {
            echo ("a new Category has been inserted successfully");
        }
    }
}
?>