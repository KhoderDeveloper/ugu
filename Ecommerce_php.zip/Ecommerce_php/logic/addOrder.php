<?php
include '../connection.php';
$shippingId = $_GET['shippingId'];
$productId = $_GET['productId'];
$total = $_GET['total'];
$date = $_GET['date'];
$status = $_GET['status'];
$size = $_GET['size'];
$qty = $_GET['qty'];

$query = "INSERT INTO `shippingorder` (`id`, `shippingId`, `productId`, `total`, `date`, `status`, `size`, `qty`)
VALUES (null, $shippingId, '$productId', $total, '$date', '$status', '$size', '$qty')";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    echo "Added";
}
?>