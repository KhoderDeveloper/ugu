<?php
include '../connection.php';
$userId = $_GET['userId'];

$query = "DELETE FROM `cart` WHERE userId = $userId";
$result = mysqli_query($conn, $query);
$query2 = "SELECT * FROM `cart` WHERE userId = $userId";
$result2 = mysqli_query($conn, $query2);
if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    if ($result2) {
        $cartLength = mysqli_num_rows($result2);
        echo $cartLength; 
    } else {
        echo "Error retrieving cart information";
    }
}
?>