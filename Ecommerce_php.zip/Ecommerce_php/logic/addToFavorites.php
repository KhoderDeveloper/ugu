<?php
include '../connection.php';
$userId = $_GET['userId'];
$productId = $_GET['productId'];


$query = "INSERT INTO `favorites`(`id`, `userId`, `productId`) VALUES (null, $userId, $productId)";

$query2 = "SELECT * FROM `favorites` WHERE userId = $userId";

$result = mysqli_query($conn, $query);
$result2 = mysqli_query($conn, $query2);

if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    if ($result2) {
        $favLength = mysqli_num_rows($result2);
        echo $favLength; 
    } else {
        echo "Error retrieving cart information";
    }
}
?>