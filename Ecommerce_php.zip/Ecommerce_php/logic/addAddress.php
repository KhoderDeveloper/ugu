<?php
include '../connection.php';
$userId = $_GET['userId'];
$address = $_GET['address'];
$street = $_GET['street'];
$building = $_GET['building'];
$cityName = $_GET['cityName'];
$phone = $_GET['phone'];

$query = "INSERT INTO `shippingaddress`(`id`, `userId`, `address`, `street`, `building`, `cityName`, `countryPhoneCode`, `phone`)
 VALUES (null,$userId, '$address', '$street', '$building', '$cityName','+961',$phone)";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    header("location:../user/cart-details.php");
}
?>