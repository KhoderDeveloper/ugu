<?php
include '../connection.php';
if (isset($_POST['productName']) && ($_POST['productName'] != "")
    && isset($_POST['producDescription']) && ($_POST['producDescription'] != "")
    && isset($_POST['productPrice']) && ($_POST['productPrice'] != 0)
    && isset($_POST['size']) && ($_POST['size'] != "")
    && isset($_POST['qty']) && ($_POST['qty'] != "")
    && isset($_POST['categoryId']) && ($_POST['categoryId'] != "")
) {
    $productName = $_POST['productName'];
    $producDescription = $_POST['producDescription'];
    $productPrice = $_POST['productPrice'];
    $discount = $_POST['discount'];
    $size = $_POST['size'];
    $qty = $_POST['qty'];
    $categoryId = $_POST['categoryId'];
    if (!empty($_FILES['productImage']['name'])) {
        $image = $_FILES['productImage']['name'];
        move_uploaded_file($_FILES['productImage']['tmp_name'], "../assets/$image");


        $query = "INSERT INTO product VALUES( null, $categoryId, '$productName', '$producDescription', '$image',
        $productPrice, null, $discount, '$size', $qty)";

        $result = mysqli_query($conn, $query);

        if (!$result) {
            die("error in insert command");
        } else {
            echo ("a new product has been inserted successfully");
        }
    }
}
?>