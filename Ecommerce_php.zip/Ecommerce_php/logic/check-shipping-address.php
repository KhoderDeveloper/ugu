<?php
include '../connection.php';
$userId = $_GET['userId'];

$query ="SELECT * FROM `shippingaddress` WHERE userId = $userId";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    $hasShippingAddress = mysqli_num_rows($result);
    echo $hasShippingAddress; 
}
?>