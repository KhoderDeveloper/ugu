<?php
include '../connection.php';
$id = $_GET['id'];
$userId = $_GET['userId'];
$query = "DELETE FROM `favorites` WHERE id = $id";
$result = mysqli_query($conn, $query);
$query2 = "SELECT * FROM `favorites` WHERE userId = $userId";
$result2 = mysqli_query($conn, $query2);
if (!$result) {
    die("Failed!" . mysqli_error($conn));
} else {
    if ($result2) {
        $favoritesLength = mysqli_num_rows($result2);
        echo $favoritesLength; 
    } else {
        echo "Error retrieving cart information";
    }
}
?>