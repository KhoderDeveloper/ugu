<?php
if (
    isset($_POST['email']) && !empty($_POST['email'])
    && isset($_POST['password']) && !empty($_POST['password'])
) {
    include 'connection.php';

    $email = $_POST['email'];
    $enteredPassword = $_POST['password'];

    // Use a prepared statement to retrieve user data
    $query = "SELECT * FROM user WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && $row = mysqli_fetch_assoc($result)) {
        $hashedPassword = $row['password'];

        if (password_verify($enteredPassword, $hashedPassword)) {
            session_start();
            if($row['role'] == 'admin'){
                header("location:admin/admin.php");
                $_SESSION['isLoggedIn'] = 1;
                $_SESSION['userId'] = $row['id'];
                $_SESSION['user'] = $row['fullName']; 
            }
            else{
                $_SESSION['isLoggedIn'] = 1;
                $_SESSION['userId'] = $row['id'];
                $_SESSION['user'] = $row['fullName']; 
                header("location:user/home.php");
            }
        } else {
            header("location:index.php");
        }
    } else {
        header("location:index.php");
    }
}
?>

