function changeSize(element) {
    // Remove 'selected-size' class from all elements
    var sizeElements = document.querySelectorAll('.size-desc, .selected-size');
    sizeElements.forEach(function (el) {
        el.classList.remove('selected-size');
    });

    // Add 'selected-size' class to the clicked element
    element.classList.add('selected-size');
}

function updateValue(id, operation) {
    var valueElement = document.getElementById(id);
    var currentValue = parseInt(valueElement.innerText);

    if (operation === 'plus') {
        valueElement.innerText = currentValue + 1;
    } else if (operation === 'minus' && currentValue > 0) {
        valueElement.innerText = currentValue - 1;
    }
}

function updateCartValue(id, operation, price, id2) {
    var valueElement = document.getElementById(id);

    var currentValue = parseInt(valueElement.innerText);

    var productpriceElement = document.getElementById(id2);
    var productprice = parseFloat(productpriceElement.innerText.replace('$', '').trim());

    var subtotalElement = document.getElementById('subtotal');
    var currentSubtotal = parseFloat(subtotalElement.innerText.replace('$', '').trim());

    if (operation === 'plus') {
        valueElement.innerText = currentValue + 1;
        var newTotal = currentSubtotal + price;
        var newprice = productprice + price
    } else if (operation === 'minus' && currentValue > 0) {
        valueElement.innerText = currentValue - 1;
        newTotal = currentSubtotal - price;
        newprice = productprice - price
    }

    productpriceElement.innerText = newprice.toFixed(0) + ' $';
    subtotalElement.innerText = newTotal.toFixed(2) + ' $';
}


function addToCart(userId, productId) {

    var selectedSizeElement = document.querySelector('.selected-size');
    var size = selectedSizeElement ? selectedSizeElement.innerText : '';

    var qtyElement = document.getElementById('value');
    var qty = qtyElement ? parseInt(qtyElement.innerText) : 0;

    if (size === null || size === '') {
        alert('Please select a size before adding to cart.');
        return;
    }

    if (qty === 0) {
        alert('Please select a quantity greater than 0 before adding to cart.');
        return;
    }

    let ajaxRequest = new XMLHttpRequest();
    ajaxRequest.onreadystatechange = function () {
        if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
            var updatedCartLength = parseInt(ajaxRequest.responseText);

            var cartElement = document.getElementById('cart');
            cartElement.innerText = updatedCartLength;
        }
    }

    ajaxRequest.open("GET", "../logic/addToCart.php?userId=" + userId + "&productId=" + productId + "&size=" + size + "&qty=" + qty, true);
    ajaxRequest.send();

}

function addToFavorites(userId, productId) {

    let ajaxRequest = new XMLHttpRequest();
    ajaxRequest.onreadystatechange = function () {
        if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
            window.location.reload()
            var updatedCFavLength = parseInt(ajaxRequest.responseText);

            var favElement = document.getElementById('favorites');
            favElement.innerText = updatedCFavLength;
            if (parseInt(favElement.innerText) === 0) {
                favElement.style.display = 'none';
            }
        }
    }

    ajaxRequest.open("GET", "../logic/addToFavorites.php?userId=" + userId + "&productId=" + productId, true);
    ajaxRequest.send();
}

function deleteRecord(id, userId, id2) {

    var productpriceElement = document.getElementById(id2);
    var productprice = parseFloat(productpriceElement.innerText.replace('$', '').trim());

    var subtotalElement = document.getElementById('subtotal');
    var currentSubtotal = parseFloat(subtotalElement.innerText.replace('$', '').trim());

    var newTotal = currentSubtotal - productprice;

    // Assuming you use AJAX to send a request to the server to delete the record
    var confirmation = confirm("Are you sure you want to delete this record?");
    if (confirmation) {
        let ajaxRequest = new XMLHttpRequest();
        ajaxRequest.onreadystatechange = function () {
            if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
                var updatedCartLength = parseInt(ajaxRequest.responseText);

                var cartElement = document.getElementById('cart');
                cartElement.innerText = updatedCartLength;

                subtotalElement.innerText = newTotal.toFixed(2) + ' $';

                removeRecordFromDOM(id);
            }
        }
        ajaxRequest.open("GET", "../logic/delete-cart.php?id=" + id + "&userId=" + userId, true);
        ajaxRequest.send();
    }
}

function removeRecordFromDOM(id) {
    var elementToRemove = document.getElementById('record_' + id);
    if (elementToRemove) {
        elementToRemove.remove();
    }
}

function deletefavorites(id, userId) {
    // Assuming you use AJAX to send a request to the server to delete the record
    let ajaxRequest = new XMLHttpRequest();
    ajaxRequest.onreadystatechange = function () {
        if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {

            var updatedfavLength = parseInt(ajaxRequest.responseText);

            var favElement = document.getElementById('favorites');
            favElement.innerText = updatedfavLength;
            removeRecordFromfavorites(id);
            window.location.reload();
        }
    }
    ajaxRequest.open("GET", "../logic/delete-favorites.php?id=" + id + "&userId=" + userId, true);
    ajaxRequest.send();
}

function removeRecordFromfavorites(id) {
    var elementToRemove = document.getElementById('fav_record_' + id);
    if (elementToRemove) {
        elementToRemove.remove();
    }
}

function checkout(userId, productId, size, qty, shippingId) {
    let ajaxRequest = new XMLHttpRequest();
    ajaxRequest.onreadystatechange = function () {
        if (ajaxRequest.readyState == 4 && ajaxRequest.status == 200) {
            var hasShippingAddress = ajaxRequest.responseText;
            if (hasShippingAddress == 0) {
                window.location.href = '../user/shipping-address.php';
            } else {
                let ajaxRequest2 = new XMLHttpRequest();
                ajaxRequest2.onreadystatechange = function () {
                    if (ajaxRequest2.readyState == 4 && ajaxRequest2.status == 200) {
                        let ajaxRequest3 = new XMLHttpRequest();
                        ajaxRequest3.onreadystatechange = function () {
                            if (ajaxRequest3.readyState == 4 && ajaxRequest3.status == 200) {

                                var elementToRemove = document.getElementById('cartRemove');
                                if (elementToRemove) {
                                    elementToRemove.style.display = 'none';
                                }

                                var subtotalElement = document.getElementById('subtotal');
                                if (subtotalElement) {
                                    subtotalElement.textContent = '0.00 $';
                                }

                                var updatedCartLength = parseInt(ajaxRequest3.responseText);

                                var cartElement = document.getElementById('cart');
                                cartElement.innerText = updatedCartLength;

                                alert('Order created!');

                            }
                        }
                        ajaxRequest3.open("GET", "../logic/drop-cart.php?userId=" + userId, true);
                        ajaxRequest3.send();
                    }
                }
                var currentDate = new Date();
                var formattedDate = currentDate.toISOString().split('T')[0];

                var subtotalElement = document.getElementById("subtotal");
                var subtotalText = subtotalElement.textContent.trim();
                var subtotalValue = parseFloat(subtotalText.replace('$', '').replace(',', ''));

                var url = "../logic/addOrder.php?shippingId=" + shippingId +
                    "&productId=" + productId +
                    "&total=" + subtotalValue +
                    "&date=" + formattedDate +
                    "&status=confirmed" +
                    "&size=" + size +
                    "&qty=" + qty;

                console.log(url)

                ajaxRequest2.open("GET", url, true);
                ajaxRequest2.send();
            }
        }
    }

    ajaxRequest.open("GET", "../logic/check-shipping-address.php?userId=" + encodeURIComponent(userId), true);
    ajaxRequest.send();
}