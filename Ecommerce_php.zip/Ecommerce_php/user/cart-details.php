<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart Details</title>


    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../scripts/product-details.js" ></script>
    <link rel="stylesheet" href="../css/home.css">
</head>

<body>
    <?php
    include '../connection.php';

    session_start();
    if ($_SESSION['isLoggedIn'] != 1) {
        header("location:../index.php");
    }

    $userId = $_SESSION['userId'];
    $query1 = "SELECT * FROM `cart` where userId = $userId";
    $query4 = "SELECT * FROM `favorites` where userId = $userId";
    $query5 = "SELECT * FROM `shippingaddress` WHERE userId = $userId";
    $result1 = mysqli_query($conn, $query1);
    $result4 = mysqli_query($conn, $query4);
    $result5 = mysqli_query($conn, $query5);

    $shippingOrder = mysqli_fetch_row($result5);

    $cartLengh = mysqli_num_rows($result1);
    $favLength = mysqli_num_rows($result4);
    $total = 0;
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container w-95">
            <a class="navbar-brand" href="home.php">BP Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="view-favorites.php"><i class="fa-solid fa-heart"></i><span class="favorites" id="favorites"><?php echo $favLength ?></span></a>
                    </li>
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="#"><i class="fa-solid fa-cart-shopping"></i><span class="cart" id="cart"><?php echo $cartLengh ?></span></a>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $user = $_SESSION['user'];
                                echo "$user";
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="row w-100 mb-2 mt-55">
        <div class="col-md-9">
            <div id="cartRemove">
                <?php
                $productIds = '';
                $sizeString = '';
                $qtyString = '';
                for ($i = 0; $i < $cartLengh; $i++) {
                    $row = mysqli_fetch_row($result1);
                    $query2 = "SELECT * FROM `product` WHERE id = $row[2];";
                    $result2 = mysqli_query($conn, $query2);
                    $row2 = mysqli_fetch_row($result2);
                    $productprice = $row2[5] * $row[4];
                    echo "<div id='record_$row[0]' class='card w-100 p-1'> ";
                    echo "  <div class='row'> ";
                    echo "    <div class='col-md-3'> ";
                    echo "        <img height='100px' src='../assets/$row2[4]'> ";
                    echo "    </div> ";
                    echo "    <div class='col-md-3 d-flex align-items-center'> ";
                    echo "        <span>$row2[3]</span> ";
                    echo "    </div> ";
                    echo "    <div class='col-md-1 d-flex text-center align-items-center'> ";
                    echo "          <span id='productprice_" . $row[0] . "'> $productprice $</span>";
                    echo "    </div> ";
                    // echo "    <div class='col-md-2 d-flex text-center align-items-center'> ";
                    // echo "         <select class='form-control'  id='sizeSelect_ $row[0]'> ";
                    // echo '              <option' . ($row[3] === 'S' ? ' selected' : '') . '>S</option> ';
                    // echo '              <option' . ($row[3] === 'M' ? ' selected' : '') . '>M</option> ';
                    // echo '              <option' . ($row[3] === 'L' ? ' selected' : '') . '>L</option> ';
                    // echo '              <option' . ($row[3] === 'XL' ? ' selected' : '') . '>XL</option> ';
                    // echo "        </select> ";
                    // echo "    </div> ";
                    echo '    <div class="col-md-2 d-flex text-center align-items-center"> ';
                    echo "        <span >Size</span>";
                    echo "        <span  style='margin-left: 10px;font-weight:bold;'>$row[3]</span>";
                    echo '    </div> ';
                    echo '    <div class="col-md-2  d-flex text-center align-items-center"> ';
                    // echo '         <button class="action-button" onclick="updateCartValue(\'value_' . $row[0] . '\', \'minus\',' . $row2[5] . ',\'productprice_' . $row[0] . '\')">-</button> ';
                    echo "        <span >Quantity</span>";
                    echo "        <span id='value_" . $row[0] . "' style='margin-left: 10px;font-weight:bold;'>$row[4]</span>";
                    // echo '        <button class="action-button" onclick="updateCartValue(\'value_' . $row[0] . '\', \'plus\',' . $row2[5] . ',\'productprice_' . $row[0] . '\')">+</button> ';
                    echo '    </div> ';
                    echo "    <div class='col-md-1 d-flex align-items-center text-end'> ";
                    echo '       <i class="fa-solid fa-trash" style="margin-left: 30px; cursor: pointer;" onclick="deleteRecord(\'' . $row[0] . '\',\'' . $userId . '\',\'productprice_' . $row[0] . '\')"></i> ';
                    echo "    </div> ";
                    echo "  </div> ";
                    echo " </div> ";
                    $subtotal = $row[4] * $row2[5];
                    $total += $subtotal;
                    $productIds .= $row[2];
                    $sizeString .= $row[3];
                    $qtyString .= $row[4];

                    if ($i < $cartLengh - 1) {
                        $productIds .= ',';
                        $sizeString .= ',';
                        $qtyString .= ',';
                    }
                }
                ?>
            </div>
        </div>
        <div class="col-md-3">
            <div class='card w-100 h-20'>
                <div class='text-center'>
                    <span> Free 2-days shipping + returns</span>
                </div>
                <div style="border-bottom: 1px solid;margin: 30px 0px;"></div>
                <div class='row w-100'>
                    <span class="bold-text mb-2"> Order Summary</span>
                </div>
                <div class='justify-content-between w-100 d-flex mb-2'>
                    <span> Subtotal </span>
                    <span id="subtotal"><?php echo number_format($total, 2); ?> $ </span>
                </div>
                <div class='justify-content-between w-100 d-flex'>
                    <span> Shipping 2-Day </span>
                    <span> Free </span>
                </div>
                <div style="border-bottom: 1px solid;margin: 30px 0px;"></div>
                <button class="checkout" onclick="checkout(<?php echo $userId ?>, <?php echo $productIds ?>, 
                '<?php echo $sizeString ? $sizeString : ''?>', '<?php echo $qtyString? $qtyString :''?>', '<?php echo $shippingOrder ? $shippingOrder[0]:'' ?>')">Checkout</button>
            </div>
        </div>
    </div>

    <footer class="navbar navbar-dark bg-dark fixed-bottom">
        <div class="container w-95 footer-display">
            <div>
                <span class=""> © All Right Reserved Bp shop 2023</span>
            </div>
            <div>
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"> <i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-snapchat"></i></a>
            </div>
        </div>
    </footer>
</body>

</html>