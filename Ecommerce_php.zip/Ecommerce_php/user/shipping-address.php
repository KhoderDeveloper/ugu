<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Address</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="../scripts/product-details.js" ></script>
    <link rel="stylesheet" href="../css/home.css">
</head>

<body>
    <?php
    include '../connection.php';

    session_start();
    if ($_SESSION['isLoggedIn'] != 1) {
        header("location:../index.php");
    }
    $userId = $_SESSION['userId'];
    $query3 = "SELECT * FROM `cart` where userId = $userId";
    $query4 = "SELECT * FROM `favorites` where userId = $userId";
    $result3 = mysqli_query($conn, $query3);
    $result4 = mysqli_query($conn, $query4);
    $cartLengh = mysqli_num_rows($result3);
    $favLength = mysqli_num_rows($result4);
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container w-95">
            <a class="navbar-brand" href="home.php">BP Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="view-favorites.php"><i class="fa-solid fa-heart"></i><span class="favorites" id="favorites"><?php echo $favLength ?></span></a>
                    </li>
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="cart-details.php"><i class="fa-solid fa-cart-shopping"></i><span class="cart"><?php echo $cartLengh ?></span></a>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $user = $_SESSION['user'];
                                echo "$user";
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <div class="d-flex top-prod jc-center mt-90">
    </div>

    <div class="container">
        <h2 class="text-center">Address</h2>
        <form action="../logic/addAddress.php" method="GET">
            <input type="hidden" name="userId" value="<?php echo $userId; ?>">
            <div class="mb-3">
                <label for="street" class="form-label">Address *</label>
                <input type="text" class="form-control" name="address" placeholder="Enter address" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Street *</label>
                <input type="text" class="form-control" name="street" placeholder="Enter street" required>
            </div>
            <div class="mb-3">
                <label for="building" class="form-label">Building *</label>
                <input type="text" class="form-control" name="building" placeholder="Enter building" required>
            </div>
            <div class="mb-3">
                <label for="cityName" class="form-label">City Name *</label>
                <input type="text" class="form-control" name="cityName" placeholder="Enter country name" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone *</label>
                <input type="number" class="form-control" name="phone" placeholder="Enter phone number" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
        </form>
    </div>

    <footer class="navbar navbar-dark bg-dark fixed-bottom">
        <div class="container w-95 footer-display">
            <div>
                <span class=""> © All Right Reserved Bp shop 2023</span>
            </div>
            <div>
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"> <i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-snapchat"></i></a>
            </div>
        </div>
    </footer>

</body>

</html>