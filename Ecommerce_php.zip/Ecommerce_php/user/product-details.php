<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/home.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../scripts/product-details.js"></script>
</head>

<body>
    <?php
    include '../connection.php';

    session_start();
    if ($_SESSION['isLoggedIn'] != 1) {
        header("location:../index.php");
    }

    $userId = $_SESSION['userId'];
    $productId = isset($_GET['id']) ? $_GET['id'] : null;
    $query1 = "SELECT * FROM `product` WHERE id = $productId ";
    $result = mysqli_query($conn, $query1);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    }
    $query3 = "SELECT * FROM `cart` where userId = $userId";
    $query4 = "SELECT * FROM `favorites` where userId = $userId";
    $result3 = mysqli_query($conn, $query3);
    $result4 = mysqli_query($conn, $query4);
    $cartLengh = mysqli_num_rows($result3);
    $favLength = mysqli_num_rows($result4);
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container w-95">
            <a class="navbar-brand" href="home.php">BP Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="view-favorites.php"><i class="fa-solid fa-heart"></i><span class="favorites" id="favorites"><?php echo $favLength ?></span></a>
                    </li>
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="cart-details.php"><i class="fa-solid fa-cart-shopping"></i><span class="cart" id="cart"><?php echo $cartLengh ?></span></a>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $user = $_SESSION['user'];
                                echo "$user";
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <div class="container mb-5" style="margin-top: 90px;">
        <div class="row">
            <div class="col-md-5">
                <img src='../assets/<?php echo $row['productImage']; ?>' height='400px'>
            </div>
            <div class="col-md-7">
                <div class='d-flex name-price mt-2 mb-2'>
                    <div>
                        <?php
                        echo $row['productName'];
                        ?>
                    </div>
                    <div>
                        <?php
                        echo $row['productPrice'];
                        ?>$
                    </div>
                </div>
                <div class="bottom-border"></div>
                <div class='d-flex description1 mt-2 mb-2'>
                    <div>
                        <?php
                        echo $row['producDescription'];
                        ?>
                    </div>
                </div>
                <div class="bottom-border"></div>
                <div class='d-block size mt-2 mb-2'>
                    <div>
                        Size :
                    </div>

                    <div class="d-flex jc-center">
                        <div class="size-desc" onclick="changeSize(this)">
                            S
                        </div>
                        <div class="size-desc" onclick="changeSize(this)">
                            M
                        </div>
                        <div class="size-desc" onclick="changeSize(this)">
                            L
                        </div>
                        <div class="size-desc" onclick="changeSize(this)">
                            XL
                        </div>
                    </div>
                </div>
                <div class="bottom-border"></div>
                <div class='d-block size mt-2 mb-2'>
                    <div>
                        Quantity:
                    </div>
                    <div class="d-flex justify-content-between align-item-center">
                        <button class="action-button2" onclick="updateValue('value', 'minus')">-</button>
                        <span id="value">1</span>
                        <button class="action-button2" onclick="updateValue('value', 'plus')">+</button>
                    </div>
                </div>
                <div class="bottom-border"></div>
                <div class="text-center mt-4">
                    <button class="add-btn" onclick="addToCart(<?php echo $userId; ?>, <?php echo $productId; ?>)">Add to Cart</button>
                </div>
            </div>

        </div>

    </div>

    <footer class="navbar navbar-dark bg-dark fixed-bottom">
        <div class="container w-95 footer-display">
            <div>
                <span class=""> © All Right Reserved Bp shop 2023</span>
            </div>
            <div>
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"> <i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-snapchat"></i></a>
            </div>
        </div>
    </footer>

</body>

</html>