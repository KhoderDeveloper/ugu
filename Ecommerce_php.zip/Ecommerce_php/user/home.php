<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="../scripts/product-details.js" ></script>
    <link rel="stylesheet" href="../css/home.css">
</head>

<body>
    <?php
    include '../connection.php';

    $userId = isset($_SESSION['userId']) ? $_SESSION['userId'] : null;
    if ($_SESSION['isLoggedIn'] != 1) {
        header("location:../index.php");
    }
    $userId = $_SESSION['userId'];
    $query1 = "SELECT * FROM product WHERE discount IS NULL  LIMIT 5";
    $query2 = "SELECT * FROM `product` WHERE discount IS NOT NULL LIMIT 5";
    $query3 = "SELECT * FROM `cart` where userId = $userId";
    $query4 = "SELECT * FROM `favorites` where userId = $userId";
    $result1 = mysqli_query($conn, $query1);
    $result2 = mysqli_query($conn, $query2);
    $result3 = mysqli_query($conn, $query3);
    $result4 = mysqli_query($conn, $query4);
    $cartLengh = mysqli_num_rows($result3);
    $favLength = mysqli_num_rows($result4);
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container w-95">
            <a class="navbar-brand" href="#">BP Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="view-favorites.php"><i class="fa-solid fa-heart"></i><span class="favorites" id="favorites"><?php echo $favLength ?></span></a>
                    </li>
                    <li class="nav-item" style="margin-right: 10px;">
                        <a class="nav-link" href="cart-details.php"><i class="fa-solid fa-cart-shopping"></i><span class="cart"><?php echo $cartLengh ?></span></a>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $user = $_SESSION['user'];
                                echo $user;
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="carouselExample" class="carousel slide p-0" data-bs-ride="carousel" style="margin-top: 56px;">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../assets/1.png" height="500px" class="d-block w-100" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="../assets/2.png" height="500px" class="d-block w-100" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="../assets/3.png" height="500px" class="d-block w-100" alt="Slide 3">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <div class="container mt-3 mb-3">
        <div class="text-center">
            <div class="badge">
                Best Company Ever
            </div>
        </div>
        <h2 class="title">The Best One In Lebanon</h2>
        <p class="description text-center">
            BP Shop is one of the best companies in Lebanon, providing high-quality products with fast shipping and the best prices.
        </p>
        <div class="container d-flex">
            <div class="card w-95 mr-2">
                <i class="fa-solid fa-truck-fast"></i>
                <h3 class="card-title">Fast Shipping</h3>
                <p class="card-description">Customers finalize orders quickly with our speedy shipping services.</p>
            </div>

            <div class="card w-95 mr-2">
                <i class="fa-solid fa-bolt"></i>
                <h3 class="card-title">High Quality</h3>
                <p class="card-description">We define quality and deliver top-notch products to our customers.</p>
            </div>

            <div class="card w-95">
                <i class="fa-solid fa-money-check-dollar"></i>
                <h3 class="card-title">Best Prices</h3>
                <p class="card-description">Selling all products at competitive and affordable prices.</p>
            </div>
        </div>
    </div>

    <div class=" mb-4" style="margin:0px 20px;">
        <div class="d-flex justify-content-between">
            <h4 style="color: #4C53A5;">Top Products</h4>
            <a href="all-prod.php" style="margin-right: 30px;">See More</a>
        </div>
        <div style="display: -webkit-inline-box;">
            <?php
            $r = mysqli_num_rows($result1);
            for ($i = 0; $i < $r; $i++) {
                $row = mysqli_fetch_row($result1);
                $query6 = "SELECT * FROM `favorites` where productId = $row[0] And userId = $userId";
                $result6 = mysqli_query($conn, $query6);
                echo "<div class='card p-0 custom-card mr-2'>";
                echo "<img src='../assets/$row[4]' height='350px' class='d-block w-100 custom-image'>";
                echo " <div class='d-flex name-price mt-2 mb-2'>";
                echo "     <div>";
                echo "         $row[2]";
                echo "     </div>";
                echo "     <div>";
                echo "         $row[5] $";
                echo "     </div>";
                echo " </div>";
                echo " <div class='d-flex cus-action mb-2'>";
                echo "      <div class='mr-50 c-p'>";
                if (mysqli_num_rows($result6)) {
                    $row6 = mysqli_fetch_row($result6);
                    echo '<i class="fas fa-heart" onclick="deletefavorites( \'' . $row6[0] . '\' ,\'' . $userId . '\')"></i>'; // Full heart icon
                } else {
                    echo "<i class='fa-regular fa-heart' onclick='addToFavorites($userId,$row[0])''></i>"; // Empty heart icon
                }
                echo "     </div>";
                echo "     <div class='c-p'>";
                echo "         <a href='product-details.php?id=$row[0]'><i class='fa-solid fa-cart-plus'></i></a>";
                echo "     </div>";
                echo " </div>";
                echo " </div>";
            }
            ?>
        </div>

    </div>
    <div style="margin:0px 20px;">
        <div class="bottom-border "></div>
    </div>
    <div class=" mb-2" style="margin:0px 20px;">
        <div class="d-flex justify-content-between">
            <h4 style="color: #4C53A5;">Discount</h4>
            <a href="all-prod-discount.php" style="margin-right: 30px;">See More</a>
        </div>
        <div style="display: -webkit-inline-box;">

            <?php
            $r2 = mysqli_num_rows($result2);
            for ($i = 0; $i < $r2; $i++) {
                $row2 = mysqli_fetch_row($result2);
                $query5 = "SELECT * FROM `favorites` where productId = $row2[0] And userId = $userId";
                $result5 = mysqli_query($conn, $query5);
                echo "<div class='card p-0 custom-card mr-2'>";
                echo "<img src='../assets/$row2[4]' height='350px' class='d-block w-100 custom-image'>";
                echo "<div class='discount'>$row2[7]%</div>";
                echo " <div class='d-flex name-price mt-2 mb-2'>";
                echo "     <div>";
                echo "         $row2[2]";
                echo "     </div>";
                echo "     <div>";
                echo "         $row2[5] $";
                echo "     </div>";
                echo " </div>";
                echo " <div class='d-flex cus-action mb-2'>";
                echo "      <div class='mr-50 c-p'>";
                if (mysqli_num_rows($result5)) {
                    $row5 = mysqli_fetch_row($result5);
                    echo '<i class="fas fa-heart" onclick="deletefavorites( \'' . $row5[0] . '\' ,\'' . $userId . '\')"></i>'; // Full heart icon
                } else {
                    echo "<i class='fa-regular fa-heart' onclick='addToFavorites($userId,$row2[0])''></i>"; // Empty heart icon
                }
                echo "     </div>";
                echo "     <div class='c-p'>";
                echo "         <a href='product-details.php?id=$row2[0]'><i class='fa-solid fa-cart-plus'></i></a>";
                echo "     </div>";
                echo " </div>";
                echo " </div>";
            }
            ?>

        </div>
    </div>

    <footer class="navbar navbar-dark bg-dark ">
        <div class="container w-95 footer-display">
            <div>
                <span class=""> © All Right Reserved Bp shop 2023</span>
            </div>
            <div>
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"> <i class="fa-brands fa-instagram"></i></a>
                <a href="#"><i class="fa-brands fa-snapchat"></i></a>
            </div>
        </div>
    </footer>

</body>

</html>