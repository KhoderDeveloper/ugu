<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Address</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="../scripts/product-details.js"></script>
    <link rel="stylesheet" href="../css/home.css">
</head>

<body>
    <?php
    include '../connection.php';

    session_start();
    if ($_SESSION['isLoggedIn'] != 1) {
        header("location:../index.php");
    }
    $userId = $_SESSION['userId'];
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container w-95">
            <a class="navbar-brand" href="admin.php">BP Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $user = $_SESSION['user'];
                                echo "$user";
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <div class="d-flex top-prod jc-center mt-90">
    </div>

    <div class="container">
        <h2 class="text-center">Product</h2>
        <form action="../logic/addProduct2.php" enctype="multipart/form-data" method="POST">
            <div class="mb-3">
                <label for="street" class="form-label">Product Name *</label>
                <input type="text" class="form-control" name="productName" placeholder="Enter Product Name" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Product Description *</label>
                <input type="text" class="form-control" name="producDescription" placeholder="Enter Product Description" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Product Price *</label>
                <input type="number" class="form-control" name="productPrice" placeholder="Enter Product Price" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Discount </label>
                <input type="number" class="form-control" name="discount" placeholder="Discount" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Size </label>
                <input type="text" class="form-control" name="size" placeholder="Enter Size" required>
            </div>
            <div class="mb-3">
                <label for="street" class="form-label">Quantity </label>
                <input type="number" class="form-control" name="qty" placeholder="Enter Quantity" required>
            </div>
            <div class="mb-3">
                <label for="building" class="form-label">Category *</label>
                <select name="categoryId" class="form-control">
                    <?php
                    $query1 = "SELECT * FROM category";
                    $result1 = mysqli_query($conn, $query1);
                    $nbr = mysqli_num_rows($result1);
                    for ($i = 0; $i < $nbr; $i++) {
                        $row = mysqli_fetch_array($result1);
                        echo "<option value='" . $row['id'] . "'>" . $row['categoryName'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="building" class="form-label">Product Image *</label>
                <input type="file" class="form-control" name="productImage" placeholder="Enter Product Image" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Save</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
        </form>
    </div>


</body>

</html>