<?php
if (
    isset($_POST['fullname']) && !empty($_POST['fullname'])
    && isset($_POST['email']) && !empty($_POST['email'])
    && isset($_POST['password']) && !empty($_POST['password'])
) {
    include 'connection.php';

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Use a prepared statement to check if the user already exists
    $query = "SELECT * FROM user WHERE fullname = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $fullname);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) != 0) {
        echo 'User already exists!';
    } else {
        // Use a prepared statement for the insert query
        $query = "INSERT INTO user VALUES(NULL, ?, ?, ?, 'user')";
        $stmt2 = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt2, "sss", $fullname, $email, $password);
        mysqli_stmt_execute($stmt2);

        header("Location:index.php");
    }
}

?>